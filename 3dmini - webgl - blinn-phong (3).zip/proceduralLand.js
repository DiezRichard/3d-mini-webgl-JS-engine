
//--------------------------//
/*
function createGrid(camPosX, camPosZ) {
let cells = [];

for (let row = 0; row < gridSize; row++) {
for (let col = 0; col < gridSize; col++) {
let cell = [];

cell.scale = tileScale;
cell.rotation = { x: 0, y: 0, z: 0 };
cell.name = "cell";

cell.position = {
x: cellSize * (col + camPosX) * cell.scale-offset,
y: 0,
z: cellSize * (row + camPosZ) * cell.scale-offset
};

if (gridLimit != 0 && cell.position.x < gridLimit && cell.position.x > -gridLimit && cell.position.z < gridLimit && cell.position.z > -gridLimit) {
// Check if cell is visible in front of the camera
//let isVisible = isCellVisible(cell.position, camera.position, camera.forward);
let isVisible=true; 

// If cell is visible, create its triangles
if (isVisible) {
// Iterate through each row and column to set vertex coordinates
for (let i = 0; i < cellSize; i++) {
for (let u = 0; u < cellSize; u++) {
// Create vertices using indices of loops
cell.push([
{ x: u, y: getY(u, i, col, row, camPosX, camPosZ), z: i },
{ x: u + 1, y: getY(u + 1, i + 1, col, row, camPosX, camPosZ), z: i + 1 },
{ x: u + 1, y: getY(u + 1, i, col, row, camPosX, camPosZ), z: i }
]);

cell.push([
{ x: u, y: getY(u, i, col, row, camPosX, camPosZ), z: i },
{ x: u, y: getY(u, i + 1, col, row, camPosX, camPosZ), z: i + 1 },
{ x: u + 1, y: getY(u + 1, i + 1, col, row, camPosX, camPosZ), z: i + 1 }
]);
}
}

// Push the cell to the cells array
cells.push(cell);
}//is in front of the camera
}//gridLimit
}//col
}//row

return cells;

}//createGrid
*/
//chunks management
function createGrid(camPosX, camPosZ) {
  let cells = [];
  
  for (let row = 0; row < gridSize; row++) {
    for (let col = 0; col < gridSize; col++) {
      // Calculamos coords del chunk (pueden ser relativas a camPos)
      const chunkX = col + camPosX;
      const chunkZ = row + camPosZ;
      const chunkKey = chunkX + ":" + chunkZ;
      
      // Si el chunk existe en cache, reutilizar
      if (chunkCache[chunkKey]) {
        cells.push(chunkCache[chunkKey]);
        continue;
      }
      
      // Si no existe, crear nuevo chunk
      let cell = [];
      
      cell.scale = tileScale;
      cell.rotation = { x: 0, y: 0, z: 0 };
      cell.name = "cell";
      
      cell.position = {
        x: cellSize * chunkX * cell.scale - offset,
        y: 0,
        z: cellSize * chunkZ * cell.scale - offset
      };
      
      // Control de límites (si aplican)
      if (
        gridLimit === 0 ||
        (cell.position.x < gridLimit && cell.position.x > -gridLimit &&
          cell.position.z < gridLimit && cell.position.z > -gridLimit)
      ) {
        // Aquí generás triángulos usando getY y loops (igual que antes)
        for (let i = 0; i < cellSize; i++) {
          for (let u = 0; u < cellSize; u++) {
            cell.push([
              { x: u, y: getY(u, i, col, row, camPosX, camPosZ), z: i },
              { x: u + 1, y: getY(u + 1, i + 1, col, row, camPosX, camPosZ), z: i + 1 },
              { x: u + 1, y: getY(u + 1, i, col, row, camPosX, camPosZ), z: i }
            ]);
            cell.push([
              { x: u, y: getY(u, i, col, row, camPosX, camPosZ), z: i },
              { x: u, y: getY(u, i + 1, col, row, camPosX, camPosZ), z: i + 1 },
              { x: u + 1, y: getY(u + 1, i + 1, col, row, camPosX, camPosZ), z: i + 1 }
            ]);
          }
        }
        
        // Guardamos el chunk en cache
        chunkCache[chunkKey] = cell;
        
        // Agregamos al array de retorno
        cells.push(cell);
      }
    }
  }
  
  return cells;
}

function cleanFarChunks(centerX, centerZ) {
  for (let key of chunkCache.keys()) {
    const [x, z] = key.split(',').map(Number);
    if (Math.abs(x - centerX) > 1 || Math.abs(z - centerZ) > 1) {
      chunkCache.delete(key);
    }
  }
}

//--------------------------//

 function isCellVisible(cellPosition, cameraPosition, cameraDirection) {
// Calculate vector from camera to cell
let vectorToCell = {
x: cellPosition.x - cameraPosition.x,
y: cellPosition.y - cameraPosition.y,
z: cellPosition.z - cameraPosition.z
};

// Calculate dot product manually
let dotProduct = vectorToCell.x * cameraDirection.x +
vectorToCell.y * cameraDirection.y +
vectorToCell.z * cameraDirection.z;

// Check if cell is in front of the camera
return dotProduct >= 0;
}

//--------------------------//


function getY(u, i, col, row, camPosX, camPosZ){


let seed = Math.floor(((u + (col + camPosX - offset) / tileScale)+ (i + (row + camPosZ - offset) / tileScale)));


let noiseVal = noise.perlin2((u + (col + camPosX - offset) * cellSize) / tileScale * frequency+random, (i + (row + camPosZ - offset) * cellSize) / tileScale * frequency+random , seed, octaves, persistence);


// Apply noise to Y value of vertex
let y = noiseVal * beef;

// Apply threshold
let lowThreshold = -50; // Set the threshold value here
// Apply threshold
let highThreshold = -3; // Set the threshold value here
if (y > lowThreshold&& y<highThreshold) {
//y = -3;
}

if (y > highThreshold) {
//y = -7;
}


return Math.floor(y);
//return y;
}
//--------------------------//





/*
function createFloor(size, camPosX, camPosZ, cameraPosition, cameraDirection) {
  let triangles = [];

  // Calculate the offset
  let offset = size / 2;

  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      // Define vertices for the current triangle
      let v1 = { x: col - offset + camPosX, y: getY(0, 0, col, row, camPosX, camPosZ), z: row - offset + camPosZ };
      let v2 = { x: col + 1 - offset + camPosX, y: getY(1, 0, col, row, camPosX, camPosZ), z: row - offset + camPosZ };
      let v3 = { x: col - offset + camPosX, y: getY(0, 1, col, row, camPosX, camPosZ), z: row + 1 - offset + camPosZ };

      // Create the first triangle
      let triangle1 = [v1, v2, v3];

      // Define vertices for the second triangle
      let v4 = { x: col + 1 - offset + camPosX, y: getY(1, 1, col, row, camPosX, camPosZ), z: row + 1 - offset + camPosZ };

      // Create the second triangle
      let triangle2 = [v3, v2, v4];


        triangles.push(triangle1);
      
      
        triangles.push(triangle2);
      
    }
  }

  triangles.scale = tileScale;
  triangles.rotation = { x: 0, y: 0, z: 0 };
  triangles.name = "cell";

  triangles.position = {
    x: 0,
    y: 0,
    z: 0
  };

  return triangles;
}



function isTriangleVisible(triangle, cameraPosition, cameraDirection) {
  // Calculate the normal vector of the triangle
  let edge1 = {
    x: triangle[1].x - triangle[0].x,
    y: triangle[1].y - triangle[0].y,
    z: triangle[1].z - triangle[0].z
  };
  let edge2 = {
    x: triangle[2].x - triangle[0].x,
    y: triangle[2].y - triangle[0].y,
    z: triangle[2].z - triangle[0].z
  };
  let normal = {
    x: edge1.y * edge2.z - edge1.z * edge2.y,
    y: edge1.z * edge2.x - edge1.x * edge2.z,
    z: edge1.x * edge2.y - edge1.y * edge2.x
  };

  // Calculate vector from camera to triangle
  let vectorToTriangle = {
    x: triangle[0].x - cameraPosition.x,
    y: triangle[0].y - cameraPosition.y,
    z: triangle[0].z - cameraPosition.z
  };

  // Calculate dot product manually
  let dotProduct = normal.x * vectorToTriangle.x +
    normal.y * vectorToTriangle.y +
    normal.z * vectorToTriangle.z;

  // Check if triangle is in front of the camera
  return dotProduct >= 0;
}
*/